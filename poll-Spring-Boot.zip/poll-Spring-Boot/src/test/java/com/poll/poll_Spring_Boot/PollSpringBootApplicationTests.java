package com.poll.poll_Spring_Boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PollSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
